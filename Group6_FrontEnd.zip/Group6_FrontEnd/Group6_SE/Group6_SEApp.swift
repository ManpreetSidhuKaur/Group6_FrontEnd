//
//  Group6_SEApp.swift
//  Group6_SE
//
//  Created by manpreet kaur on 2025-03-01.
//

import SwiftUI

@main
struct Group6_SEApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
