import Foundation
import SocketIO

class ChatViewModel: ObservableObject {
    @Published var message = ""
    @Published var chatHistory: [String] = [
        "You: Hi, I'm not feeling very good today.",
        "AI: What seems to be the problem?"
    ]

    private var manager: SocketManager!
    public var socket: SocketIOClient!

    init() {
        setupSocket()
    }

    private func setupSocket() {
        manager = SocketManager(socketURL: URL(string: "http://localhost:5001")!, config: [.log(true), .forceWebsockets(true)])
        socket = manager.defaultSocket

        // Connect and listen
        socket.on(clientEvent: .connect) { data, ack in
            print("Socket connected")
        }

        socket.on("response") { data, ack in
            if let response = data.first as? String {
                DispatchQueue.main.async {
                    self.chatHistory.append("AI: \(response)")
                }
            }
        }


        socket.connect()
    }

    deinit {
        socket.disconnect()
    }

    func sendMessageToAI() {
        guard !message.trimmingCharacters(in: .whitespaces).isEmpty else { return }

        let userMessage = message
        DispatchQueue.main.async {
            self.chatHistory.append("You: \(userMessage)")
            self.message = ""
        }

        socket.emit("message", userMessage)
    }
}
