import SwiftUI

struct ChatViewUI: View {
    @StateObject private var chatViewModel = ChatViewModel()  // Using ChatViewModel here

    var body: some View {
        ZStack {
            Color.blue.opacity(0.1).edgesIgnoringSafeArea(.all)
            
            VStack {
                List(chatViewModel.chatHistory, id: \.self) { message in
                    Text(message)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 2)
                }

                HStack {
                    TextField("Type a message...", text: $chatViewModel.message)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 2)

                    Button("Send") {
                        chatViewModel.sendMessageToAI()  // Now calling the ViewModel's method
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .shadow(radius: 3)
                }
                .padding()
            }
        }
    }
}
